package strategies;

import cantstop.Jeu;

import java.util.Random;

public class Strat49 implements Strategie {

    public static double DELEMITER = 0.66;
    private final Random rng = new Random();
    int maxStep = 4; // ok avec 5 aussi
    private int currentStep = 0;

    public Strat49() {
    }

    @Override
    public int choix(Jeu j) {
        int[][] choix = j.getLesChoix();
        int[][] bonzes = j.getBonzes();

        int bestChoice = -1;
        for (int i = 0; i < j.getNbChoix(); i++) {
            if (choix[i][0] == choix[i][1]) {
                if (bestChoice == -1) bestChoice = i;
                else {
                    for (int[] bonze : bonzes) {
                        if (bonze[0] == choix[i][0] + 2) {
                            for (int[] bonze2 : bonzes) {
                                if (bonze2[0] == choix[bestChoice][0] + 2) {
                                    if (bonze[1] > bonze2[1]) bestChoice = i;
                                }
                            }
                        }
                    }
                }
            }
            if (bestChoice == -1) {
                for (int[] bonze : bonzes) {
                    if (bonze[0] == choix[i][0] + 2 || bonze[0] == choix[i][1] + 2) {
                        bestChoice = i;
                        break;
                    }
                }
            } else {

            }
        }
        currentStep++;
        //System.out.println(bestChoice);
        //System.out.println(Arrays.toString(choix[bestChoice]));
        return bestChoice == -1 ? rng.nextInt(j.getNbChoix()) : bestChoice;
        //return strats.get(rng.nextInt(0, strats.size())).choix(j);
    }

    @Override
    public boolean stop(Jeu j) {
        boolean shouldStop = rng.nextDouble(0, Math.max(maxStep - currentStep + 1, 1)) < DELEMITER;
        if (shouldStop) {
            currentStep = 0;
            return true;
        } else {
            return false;
        }
    }

    @Override
    public String getName() {
        return "Strat49";
    }
}
